Final ZYVO icon will be added after the image-generation limit resets. This folder is reserved for branding assets.
