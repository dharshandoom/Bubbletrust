# ZYVO Real App Starter

Starting point for the real ZYVO app. Firebase configuration is intentionally not included yet.

Planned: authentication, real-time chat, groups, friends, best-friend emoji, 5 pinned chats, themes, disappearing messages, media, games, reels, calls and nearby-friends privacy controls.
