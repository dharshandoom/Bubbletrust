import 'package:flutter/material.dart';

void main() => runApp(const ZyvoApp());

class ZyvoApp extends StatelessWidget {
  const ZyvoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ZYVO',
    theme: ThemeData(brightness: Brightness.dark, useMaterial3: true, colorSchemeSeed: Colors.cyan, scaffoldBackgroundColor: const Color(0xFF080B14)),
    home: const ZyvoShell(),
  );
}

class ZyvoShell extends StatefulWidget { const ZyvoShell({super.key}); @override State<ZyvoShell> createState()=>_ZyvoShellState(); }
class _ZyvoShellState extends State<ZyvoShell> {
  int index=0;
  final pages=const [
    Center(child: Text('💬 Chat\n\nReal-time chat setup is next.',textAlign:TextAlign.center,style:TextStyle(fontSize:20))),
    Center(child: Text('🎮 Games\n\nTic-Tac-Toe • Rock Paper Scissors',textAlign:TextAlign.center,style:TextStyle(fontSize:20))),
    Center(child: Text('🎬 Reels\n\nShort-video feed',textAlign:TextAlign.center,style:TextStyle(fontSize:20))),
    Center(child: Text('👥 Friends\n\nFind friends • Requests • Best Friends',textAlign:TextAlign.center,style:TextStyle(fontSize:20))),
    Center(child: Text('👤 Profile\n\nUsername • Nickname • Photo • Followers',textAlign:TextAlign.center,style:TextStyle(fontSize:20))),
  ];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('ZYVO',style:TextStyle(fontWeight:FontWeight.w800)),centerTitle:true),
    body:SafeArea(child:pages[index]),
    bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const[
      NavigationDestination(icon:Icon(Icons.chat_bubble_outline),label:'Chat'),
      NavigationDestination(icon:Icon(Icons.sports_esports_outlined),label:'Games'),
      NavigationDestination(icon:Icon(Icons.play_circle_outline),label:'Reels'),
      NavigationDestination(icon:Icon(Icons.people_outline),label:'Friends'),
      NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile'),
    ]),
  );
}
